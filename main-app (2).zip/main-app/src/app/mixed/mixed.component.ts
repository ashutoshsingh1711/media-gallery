import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { Gallery, GalleryRef } from 'ng-gallery';

@Component({
  selector: 'app-mixed',
  templateUrl: './mixed.component.html',
  styleUrls: ['./mixed.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MixedComponent implements OnInit {

  galleryId = 'app-mixed';

  constructor(private gallery: Gallery) { }

  ngOnInit() {
    const galleryRef: GalleryRef = this.gallery.ref(this.galleryId);

    galleryRef.addImage({
      src: 'https://images.unsplash.com/photo-1675139380320-6ba6a0f6f8b9?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxlZGl0b3JpYWwtZmVlZHwyfHx8ZW58MHx8fHw%3D&auto=format&fit=crop&w=1000&q=60',
      thumb: 'https://images.unsplash.com/photo-1675139380320-6ba6a0f6f8b9?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxlZGl0b3JpYWwtZmVlZHwyfHx8ZW58MHx8fHw%3D&auto=format&fit=crop&w=1000&q=60'
    });
    galleryRef.addImage({
      src: 'https://plus.unsplash.com/premium_photo-1661897811474-f0972db695a8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=387&q=80',
      thumb: 'https://plus.unsplash.com/premium_photo-1661897811474-f0972db695a8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=387&q=80'
    });
    galleryRef.addImage({
      src: 'https://images.unsplash.com/photo-1661961110144-12ac85918e40?ixlib=rb-4.0.3&ixid=MnwxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80',
      thumb: 'https://images.unsplash.com/photo-1661961110144-12ac85918e40?ixlib=rb-4.0.3&ixid=MnwxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80'
    });

    galleryRef.addVideo({
      src: 'D:\main-app\src\assets\pexels-tima-miroshnichenko-5377684.mp4',
      thumb: 'D:\main-app\src\assets\pexels-tima-miroshnichenko-5377684.mp4',
      poster: '(OPTIONAL)VIDEO_POSTER_URL'
    });

    galleryRef.addYoutube({
      src: 'https://www.youtube.com/watch?v=hxCCkPRLBsg'
    });

    galleryRef.addIframe({
      src: 'https://www.google.com/',
      thumb: 'https://www.google.com/'
    });
  }
}